let cijfer = prompt("Welk cijfer wil je voor je cijferruit?");
let lijstje = "";
for (let getallen = 1; getallen <= cijfer; getallen++){
    lijstje += getallen;
    document.getElementById("antwoord").innerText += lijstje+ '\n';
    lijstje = getallen === parseInt(cijfer) ? lijstje += "" : lijstje += "-";
}
for (let number = cijfer; number >= 1; number--) {
    lijstje = lijstje.replace(number, '').split("").reverse().join("").replace('-', '').split("").reverse().join("");
    document.getElementById("antwoord").innerText += lijstje + '\n';
}