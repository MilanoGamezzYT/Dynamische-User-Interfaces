const products = {"koffie": 3.50, "cola": 3.20, "red bull": 4.75};
const receipt = {};

let total = 0;
let stop = false;
let userInput;
let productAmount = NaN;
let amountNaN = true;

while (!stop) {
    userInput = prompt(`Wat zou u willen bestellen? (Type 'stop' om het te beeindigen.)\nProduct choices: ${Object.keys(products)}`);

    if (userInput === "stop") {
        stop = true;
    } else {
        if (!(userInput in products)) {
            alert(`Momenteen is (${userInput}) uitverkocht. Sorry voor dit ongemak.`);
        } else {
            while (amountNaN) {
                productAmount = parseInt(prompt(`Hoeveel ${userInput} wilt u bestellen?`));
                if (!isNaN(productAmount)) {
                    amountNaN = false;
                }
            }

            amountNaN = true;

            if (userInput in receipt) {
                receipt[userInput] += productAmount;
            } else {
                receipt[userInput] = productAmount;
            }

            total += productAmount * products[userInput];
        }
    }
}

for (const [key, value] of Object.entries(receipt)) {
    const display = `${value}x ${key} - $${(value*products[key]).toFixed(2)}`
    document.getElementById("Bonnetje").innerText = "Uw Bonnetje - Bedankt voor het bestellen!";
    document.getElementById("Dranken").innerText += display + '\n';
}

if (total > 0) {
    document.getElementById("Totale_prijs").innerText = "Total: $" + total.toFixed(2);
}




